import style from './Section.module.css'


function Section(){
   return(
       <section className={style.section}>
               <p>SECTION</p>
       </section>
   )
}

export default Section