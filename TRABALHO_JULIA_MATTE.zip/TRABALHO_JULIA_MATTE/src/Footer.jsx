import style from './Footer.module.css'
import text from './Text.module.css'

export default function Footer(){
   return(
       <footer className={style.footer}>
               <p>FOOTER</p>
       </footer>
   )
}
