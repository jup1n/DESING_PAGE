import style from './Header.module.css'

function Header(){
   return(
       <header className={style.header}>
               <p>CESUL</p>
       </header>
   )
}

export default Header