import style from './Menu.module.css'
import text from './Text.module.css'

function Menu(){
   return(
       <section className={style.menu}>
               <p>MENU</p>
       </section>
   )
}

export default Menu